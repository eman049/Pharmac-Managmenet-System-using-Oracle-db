# ==============================
# app.py (Robust Version)
# ==============================
from flask import Flask, render_template, request, redirect, session, abort, flash
import oracledb
import hashlib
import base64
import os

app = Flask(__name__)
app.secret_key = "pms_secret"

# ---------------- DATABASE CONNECTION ----------------
try:
    conn = oracledb.connect(
        user="PMS_DB",
        password="pms123",
        dsn="localhost:1521/XEPDB1"
    )
    print("Database connected successfully!")
except Exception as e:
    print("Database connection failed:", e)
    conn = None

# ---------------- ROLE CHECKS ----------------
def admin_only():
    if session.get('role') != 'ADMIN':
        abort(403)

def pharmacist_only():
    if session.get('role') != 'PHARMACIST':
        abort(403)

# ---------------- GLOBAL SCRYPT PARAMETERS ----------------
SCRYPT_N = 8192
SCRYPT_r = 8
SCRYPT_p = 1
SCRYPT_dklen = 64

# ---------------- SCRYPT HASH FUNCTIONS ----------------
def generate_scrypt_hash(password):
    salt = os.urandom(16)
    hash_bytes = hashlib.scrypt(
        password.encode(),
        salt=salt,
        n=SCRYPT_N,
        r=SCRYPT_r,
        p=SCRYPT_p,
        dklen=SCRYPT_dklen
    )
    hash_string = (
        f"scrypt:{SCRYPT_N}:{SCRYPT_r}:{SCRYPT_p}$"
        f"{base64.b64encode(salt).decode()}$"
        f"{base64.b64encode(hash_bytes).decode()}"
    )
    return hash_string

def verify_scrypt(db_hash, password):
    try:
        if not db_hash.startswith("scrypt:"):
            return False
        parts = db_hash.split('$')
        params = parts[0].split(':')
        N = int(params[1])
        r = int(params[2])
        p = int(params[3])
        salt = base64.b64decode(parts[1])
        stored_hash = base64.b64decode(parts[2])
        test_hash = hashlib.scrypt(
            password.encode(),
            salt=salt,
            n=N,
            r=r,
            p=p,
            dklen=len(stored_hash)
        )
        return test_hash == stored_hash
    except Exception as e:
        print("SCRYPT VERIFY ERROR:", e)
        return False

# ---------------- RESET ADMIN PASSWORDS ----------------
@app.route('/reset_admin_passwords')
def reset_admin_passwords():
    if conn is None:
        return "DB connection not available!"
    users = {
        "adminA": "emf@rqk123",
        "adminB": "emf@rqk123",
        "adminC": "emf@rqk123",
        "adminD": "emf@rqk123"
    }
    try:
        cur = conn.cursor()
        for username, pwd in users.items():
            hash_str = generate_scrypt_hash(pwd)
            cur.execute("""
                UPDATE users
                SET password = :p
                WHERE username = :u
            """, {'p': hash_str, 'u': username})
        conn.commit()
        return "All admin passwords reset successfully!"
    except Exception as e:
        return f"Error resetting passwords: {e}"

# ---------------- LOGIN ----------------
@app.route('/', methods=['GET', 'POST'])
def login():
    if conn is None:
        return "DB connection not available!"
    if request.method == 'POST':
        u = request.form['username']
        p = request.form['password']
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT user_id, password, role, company_id
                FROM users
                WHERE username = :u
            """, {'u': u})
            row = cur.fetchone()
            if row and verify_scrypt(row[1], p):
                session['uid'] = row[0]
                session['role'] = row[2]
                session['cid'] = row[3]
                return redirect('/dashboard')
            else:
                flash("Invalid username or password")
                return render_template('login.html')
        except Exception as e:
            print("Login error:", e)
            flash("An error occurred. Try again.")
            return render_template('login.html')
    return render_template('login.html')

# ---------------- SIGNUP ----------------
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if conn is None:
        return "DB connection not available!"
    try:
        cur = conn.cursor()
        cur.execute("SELECT company_id, name FROM companies")
        companies = cur.fetchall()
    except Exception as e:
        return f"Error fetching companies: {e}"

    if request.method == 'POST':
        try:
            username = request.form['username']
            password = request.form['password']
            role = request.form['role']
            company = request.form['company']
            hash_string = generate_scrypt_hash(password)
            cur.execute("""
                INSERT INTO users
                VALUES (users_seq.NEXTVAL, :u, :p, :r, :c)
            """, {'u': username, 'p': hash_string, 'r': role, 'c': company})
            conn.commit()
            flash("User created successfully")
            return redirect('/')
        except Exception as e:
            print("Signup error:", e)
            flash("Error creating user. Try again.")
            return render_template('signup.html', companies=companies)
    return render_template('signup.html', companies=companies)

# ---------------- DASHBOARD ----------------
@app.route('/dashboard')
def dashboard():
    if 'uid' not in session:
        return redirect('/')
    return render_template('dashboard.html')

# ---------------- LOGOUT ----------------
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

# ---------------- ERROR HANDLER ----------------
@app.errorhandler(403)
def forbidden(e):
    return render_template("403.html"), 403

# ---------------- RUN ----------------
if __name__ == "__main__":
    app.run(debug=True)
