/* =========================
   DROP OLD OBJECTS (OPTIONAL)
   ========================= */
DROP TABLE audit_log CASCADE CONSTRAINTS;
DROP TABLE medicines CASCADE CONSTRAINTS;
DROP TABLE users CASCADE CONSTRAINTS;
DROP TABLE companies CASCADE CONSTRAINTS;

DROP SEQUENCE seq_med;
DROP SEQUENCE seq_audit;


/* =========================
   COMPANY TABLE
   ========================= */
CREATE TABLE companies (
  company_id NUMBER PRIMARY KEY,
  name VARCHAR2(100)
);


/* =========================
   USERS TABLE
   ========================= */
CREATE TABLE users (
  user_id NUMBER PRIMARY KEY,
  username VARCHAR2(50),
  password VARCHAR2(200),
  role VARCHAR2(20),
  company_id NUMBER,
  CONSTRAINT fk_users_company
    FOREIGN KEY (company_id)
    REFERENCES companies(company_id)
);


/* =========================
   MEDICINES TABLE
   ========================= */
CREATE TABLE medicines (
  med_id NUMBER PRIMARY KEY,
  name VARCHAR2(100),
  qty NUMBER,
  price NUMBER,
  expiry DATE,
  company_id NUMBER,
  CONSTRAINT fk_meds_company
    FOREIGN KEY (company_id)
    REFERENCES companies(company_id)
);


/* =========================
   AUDIT TABLE
   ========================= */
CREATE TABLE audit_log (
  id NUMBER PRIMARY KEY,
  action VARCHAR2(200),
  log_date DATE
);


/* =========================
   SEQUENCES
   ========================= */
CREATE SEQUENCE seq_med START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_audit START WITH 1 INCREMENT BY 1;


/* =========================
   AUDIT TRIGGER
   ========================= */
CREATE OR REPLACE TRIGGER trg_audit
AFTER INSERT OR UPDATE OR DELETE
ON medicines
FOR EACH ROW
BEGIN
  INSERT INTO audit_log
  VALUES (
    seq_audit.NEXTVAL,
    'Medicines table changed',
    SYSDATE
  );
END;
/
  

/* =========================
   STORED PROCEDURE
   ========================= */
CREATE OR REPLACE PROCEDURE add_med (
  m_name     VARCHAR2,
  m_qty      NUMBER,
  m_price    NUMBER,
  m_exp      DATE,
  m_company  NUMBER
)
AS
BEGIN
  INSERT INTO medicines
  VALUES (
    seq_med.NEXTVAL,
    m_name,
    m_qty,
    m_price,
    m_exp,
    m_company
  );
END;
/
  

/* =========================
   MATERIALIZED VIEW (REPORT)
   ========================= */
CREATE MATERIALIZED VIEW med_report
BUILD IMMEDIATE
REFRESH COMPLETE
AS
SELECT company_id, COUNT(*) AS total_meds
FROM medicines
GROUP BY company_id;


/* =========================
   HORIZONTAL FRAGMENTATION
   (Views as Fragments)
   ========================= */
CREATE VIEW meds_company1 AS
SELECT * FROM medicines WHERE company_id = 1;

CREATE VIEW meds_company2 AS
SELECT * FROM medicines WHERE company_id = 2;

CREATE VIEW meds_company3 AS
SELECT * FROM medicines WHERE company_id = 3;

CREATE VIEW meds_company4 AS
SELECT * FROM medicines WHERE company_id = 4;


/* =========================
   SAMPLE DATA (4 COMPANIES)
   ========================= */
INSERT INTO companies VALUES (1, 'Pharmacy A');
INSERT INTO companies VALUES (2, 'Pharmacy B');
INSERT INTO companies VALUES (3, 'Pharmacy C');
INSERT INTO companies VALUES (4, 'Pharmacy D');


/* =========================
   SAMPLE USERS
   ========================= */
INSERT INTO users VALUES (1, 'adminA', 'admin', 'ADMIN', 1);
INSERT INTO users VALUES (2, 'adminB', 'admin', 'ADMIN', 2);
INSERT INTO users VALUES (3, 'adminC', 'admin', 'ADMIN', 3);
INSERT INTO users VALUES (4, 'adminD', 'admin', 'ADMIN', 4);


COMMIT;
