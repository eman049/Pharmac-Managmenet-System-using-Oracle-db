/* ================================================
   PMS FINAL SQL - SAFE DROP AND RECREATE
   ================================================ */

/* =========================
   DROP MATERIALIZED VIEW
   ========================= */
BEGIN
  EXECUTE IMMEDIATE 'DROP MATERIALIZED VIEW med_stock_report';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

/* =========================
   DROP VIEWS
   ========================= */
BEGIN
  EXECUTE IMMEDIATE 'DROP VIEW meds_company1';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP VIEW meds_company2';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP VIEW meds_company3';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP VIEW meds_company4';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

/* =========================
   DROP TRIGGERS
   ========================= */
BEGIN
  EXECUTE IMMEDIATE 'DROP TRIGGER trg_medicine_audit';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TRIGGER trg_low_stock_alert';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

/* =========================
   DROP PROCEDURES
   ========================= */
BEGIN
  EXECUTE IMMEDIATE 'DROP PROCEDURE add_medicine';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP PROCEDURE update_medicine';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP PROCEDURE delete_medicine';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

/* =========================
   DROP SEQUENCES
   ========================= */
BEGIN
  EXECUTE IMMEDIATE 'DROP SEQUENCE users_seq';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP SEQUENCE med_seq';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP SEQUENCE audit_seq';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP SEQUENCE backup_seq';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

/* =========================
   DROP TABLES
   ========================= */
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE medicines_backup CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE audit_log CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE medicines CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE users CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE companies CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

/* =========================
   CREATE TABLES
   ========================= */
CREATE TABLE companies (
  company_id NUMBER PRIMARY KEY,
  name VARCHAR2(100) UNIQUE
);

CREATE TABLE users (
  user_id NUMBER PRIMARY KEY,
  username VARCHAR2(50) UNIQUE,
  password VARCHAR2(300),
  role VARCHAR2(20) CHECK (role IN ('ADMIN','PHARMACIST')),
  company_id NUMBER,
  CONSTRAINT fk_user_company FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

CREATE TABLE medicines (
  med_id NUMBER PRIMARY KEY,
  name VARCHAR2(100),
  qty NUMBER CHECK (qty >= 0),
  price NUMBER CHECK (price > 0),
  expiry DATE,
  company_id NUMBER,
  CONSTRAINT fk_med_company FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

CREATE TABLE audit_log (
  audit_id NUMBER PRIMARY KEY,
  table_name VARCHAR2(50),
  operation VARCHAR2(20),
  record_id NUMBER,
  log_date DATE
);

CREATE TABLE medicines_backup (
  backup_id NUMBER PRIMARY KEY,
  med_id NUMBER,
  name VARCHAR2(100),
  qty NUMBER,
  price NUMBER,
  expiry DATE,
  company_id NUMBER,
  operation VARCHAR2(20),
  backup_date DATE
);

/* =========================
   CREATE SEQUENCES
   ========================= */
CREATE SEQUENCE users_seq START WITH 1;
CREATE SEQUENCE med_seq START WITH 1;
CREATE SEQUENCE audit_seq START WITH 1;
CREATE SEQUENCE backup_seq START WITH 1;

/* =========================
   SAMPLE COMPANIES
   ========================= */
INSERT INTO companies VALUES (1,'HealthPlus Pharmacy');
INSERT INTO companies VALUES (2,'LifeCare Medical Store');
INSERT INTO companies VALUES (3,'CityMed Pharmacy');
INSERT INTO companies VALUES (4,'Prime Health Pharmacy');

/* =========================
   CREATE TRIGGER - AUDIT + BACKUP
   ========================= */
CREATE OR REPLACE TRIGGER trg_medicine_audit
BEFORE INSERT OR UPDATE OR DELETE
ON medicines
FOR EACH ROW
BEGIN
  -- Backup old data
  IF UPDATING OR DELETING THEN
    INSERT INTO medicines_backup
    (backup_id, med_id, name, qty, price, expiry, company_id, operation, backup_date)
    VALUES
    (backup_seq.NEXTVAL, :OLD.med_id, :OLD.name, :OLD.qty, :OLD.price, :OLD.expiry, :OLD.company_id,
     CASE WHEN UPDATING THEN 'UPDATE' ELSE 'DELETE' END, SYSDATE);
  END IF;

  -- Audit log
  IF INSERTING THEN
    INSERT INTO audit_log(audit_id, table_name, operation, record_id, log_date)
    VALUES (audit_seq.NEXTVAL,'MEDICINES','INSERT',:NEW.med_id,SYSDATE);
  ELSIF UPDATING THEN
    INSERT INTO audit_log(audit_id, table_name, operation, record_id, log_date)
    VALUES (audit_seq.NEXTVAL,'MEDICINES','UPDATE',:OLD.med_id,SYSDATE);
  ELSIF DELETING THEN
    INSERT INTO audit_log(audit_id, table_name, operation, record_id, log_date)
    VALUES (audit_seq.NEXTVAL,'MEDICINES','DELETE',:OLD.med_id,SYSDATE);
  END IF;
END;
/

/* =========================
   LOW STOCK ALERT TRIGGER
   ========================= */
CREATE OR REPLACE TRIGGER trg_low_stock_alert
AFTER INSERT OR UPDATE ON medicines
FOR EACH ROW
WHEN (NEW.qty < 10)
BEGIN
  INSERT INTO audit_log(audit_id, table_name, operation, record_id, log_date)
  VALUES (audit_seq.NEXTVAL,'MEDICINES','LOW STOCK ALERT',:NEW.med_id,SYSDATE);
END;
/

/* =========================
   STORED PROCEDURES
   ========================= */
CREATE OR REPLACE PROCEDURE add_medicine (
  p_name VARCHAR2, p_qty NUMBER, p_price NUMBER, p_exp DATE, p_company NUMBER
)
AS
BEGIN
  INSERT INTO medicines VALUES (med_seq.NEXTVAL,p_name,p_qty,p_price,p_exp,p_company);
END;
/

CREATE OR REPLACE PROCEDURE update_medicine (
  p_id NUMBER, p_qty NUMBER, p_price NUMBER
)
AS
BEGIN
  UPDATE medicines SET qty=p_qty, price=p_price WHERE med_id=p_id;
END;
/

CREATE OR REPLACE PROCEDURE delete_medicine (
  p_id NUMBER
)
AS
BEGIN
  DELETE FROM medicines WHERE med_id=p_id;
END;
/

/* =========================
   HORIZONTAL FRAGMENTATION - VIEWS
   ========================= */
CREATE OR REPLACE VIEW meds_company1 AS SELECT * FROM medicines WHERE company_id = 1;
CREATE OR REPLACE VIEW meds_company2 AS SELECT * FROM medicines WHERE company_id = 2;
CREATE OR REPLACE VIEW meds_company3 AS SELECT * FROM medicines WHERE company_id = 3;
CREATE OR REPLACE VIEW meds_company4 AS SELECT * FROM medicines WHERE company_id = 4;

/* =========================
   MATERIALIZED VIEW
   ========================= */
CREATE MATERIALIZED VIEW med_stock_report
BUILD IMMEDIATE
REFRESH COMPLETE
AS
SELECT company_id, COUNT(*) total_medicines, SUM(qty) total_stock
FROM medicines
GROUP BY company_id;

/* =========================
   SAMPLE DATA
   ========================= */
BEGIN
  add_medicine('Panadol',50,30,DATE '2026-01-01',1);
  add_medicine('Brufen',5,80,DATE '2025-06-01',2);
  add_medicine('Disprin',100,10,DATE '2027-03-01',3);
  add_medicine('Paracetamol',8,15,DATE '2026-05-01',4);
END;
/
COMMIT;
