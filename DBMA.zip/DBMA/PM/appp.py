# =============================
# Smart Pharmacy Management - app.py
# =============================

from flask import Flask, render_template, redirect, url_for, session, flash, request
from flask_wtf import FlaskForm, CSRFProtect
from wtforms import StringField, PasswordField, SubmitField, SelectField, IntegerField, FloatField, DateField
from wtforms.validators import DataRequired
import oracledb
import bcrypt

# ---------------- APP SETUP ----------------
app = Flask(__name__)
app.secret_key = "secret123"
csrf = CSRFProtect(app)

# ---------------- DB CONNECTION ----------------
def get_db():
    return oracledb.connect(
        user="PMS_DB",
        password="pms123",
        dsn="localhost:1521/XEPDB1"
    )

def fetch_companies():
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT COMPANY_ID, NAME FROM companies ORDER BY COMPANY_ID")
    rows = cur.fetchall()
    cur.close(); db.close()
    return rows

def fetch_users():
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT USERNAME, PASSWORD, ROLE, COMPANY_ID FROM users")
    rows = cur.fetchall()
    users = []
    for u in rows:
        cur.execute("SELECT NAME FROM companies WHERE COMPANY_ID=:1", [u[3]])
        cname = cur.fetchone()[0]
        users.append({
            "username": u[0],
            "password": u[1],
            "role": u[2],
            "company": cname,
            "company_id": u[3]  # add company_id
        })
    cur.close(); db.close()
    return users

# ---------------- FORMS ----------------
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    company = SelectField('Company', validators=[DataRequired()])
    submit = SubmitField('Login')

class SignupForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    role = SelectField('Role', choices=[('ADMIN','ADMIN'), ('PHARMACIST','PHARMACIST')])
    company = SelectField('Company', validators=[DataRequired()])
    submit = SubmitField('Signup')

class AddMedicineForm(FlaskForm):
    name = StringField('Medicine Name', validators=[DataRequired()])
    qty = IntegerField('Quantity', validators=[DataRequired()])
    price = FloatField('Price', validators=[DataRequired()])
    expiry = DateField('Expiry', format='%Y-%m-%d', validators=[DataRequired()])
    company_id = SelectField('Company', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Save Medicine')

class AddPharmacistForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    company_id = SelectField('Company', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Add Pharmacist')

# ---------------- AUTH ROUTES ----------------
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET','POST'])
def login():
    form = LoginForm()
    form.company.choices = [(c[1], c[1]) for c in fetch_companies()]
    users = fetch_users()

    if form.validate_on_submit():
        user = next((u for u in users if u['username']==form.username.data and u['company']==form.company.data), None)
        if user and bcrypt.checkpw(form.password.data.encode(), user['password'].encode()):
            session['uid'] = user['username']
            session['role'] = user['role']
            session['company_id'] = user['company_id']  # important!
            flash(f"Welcome {user['username']}!", "success")
            return redirect(url_for('dashboard'))
        flash('Invalid credentials', 'error')

    return render_template('login.html', form=form)

@app.route('/signup', methods=['GET','POST'])
def signup():
    form = SignupForm()
    form.company.choices = [(c[1], c[1]) for c in fetch_companies()]

    if form.validate_on_submit():
        db = get_db()
        cur = db.cursor()
        hashed = bcrypt.hashpw(form.password.data.encode(), bcrypt.gensalt()).decode()
        cur.execute("SELECT COMPANY_ID FROM companies WHERE NAME=:1", [form.company.data])
        cid = cur.fetchone()[0]
        cur.execute("INSERT INTO users VALUES (user_seq.NEXTVAL,:1,:2,:3,:4)",
                    (form.username.data, hashed, form.role.data, cid))
        db.commit(); cur.close(); db.close()
        flash("Account created! Please login.", "success")
        return redirect(url_for('login'))

    return render_template('signup.html', form=form)

@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for('home'))

# ---------------- DASHBOARD ----------------
@app.route('/dashboard')
def dashboard():
    if not session.get('uid'):
        flash("Please login first.", "error")
        return redirect(url_for('login'))

    if session.get('role') == 'ADMIN':
        return redirect(url_for('admin_dashboard'))
    else:
        return redirect(url_for('pharmacist_dashboard'))

@app.route('/admin_dashboard')
def admin_dashboard():
    if session.get('role') != 'ADMIN':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    db = get_db(); cur = db.cursor()
    cur.execute("SELECT COUNT(*) FROM medicines")
    total_medicines = cur.fetchone()[0]

    # total pharmacists across all companies
    cur.execute("SELECT COUNT(*) FROM users WHERE ROLE='PHARMACIST'")
    total_pharmacists = cur.fetchone()[0]

    total_sales = 0
    cur.close(); db.close()

    return render_template('admin_dashboard.html',
                           page='dashboard',
                           total_medicines=total_medicines,
                           total_pharmacists=total_pharmacists,
                           total_sales=total_sales)

@app.route('/pharmacist_dashboard')
def pharmacist_dashboard():
    if session.get('role') != 'PHARMACIST':
        flash("Access denied!", "error")
        return redirect(url_for('login'))
    return render_template('pharmacist_dashboard.html')

# ---------------- MEDICINES ----------------
@app.route('/admin/medicines')
def view_medicines():
    db = get_db(); cur = db.cursor()
    cur.execute("SELECT MED_ID, NAME, QTY, PRICE, EXPIRY FROM medicines")
    meds = cur.fetchall(); cur.close(); db.close()
    return render_template('admin_dashboard.html', page='view_medicine', medicines=meds)

@app.route('/admin/add-medicine', methods=['GET','POST'])
def add_medicine():
    form = AddMedicineForm(); form.company_id.choices = fetch_companies()
    if form.validate_on_submit():
        db = get_db(); cur = db.cursor()
        cur.execute("""
            INSERT INTO medicines (MED_ID, NAME, QTY, PRICE, EXPIRY, COMPANY_ID)
            VALUES (med_seq.NEXTVAL, :1, :2, :3, :4, :5)
        """, (form.name.data, form.qty.data, form.price.data, form.expiry.data, form.company_id.data))
        db.commit(); cur.close(); db.close()
        flash("Medicine added successfully!", "success")
        return redirect(url_for('view_medicines'))
    return render_template('admin_dashboard.html', page='add_medicine', form=form)

@app.route('/admin/delete-medicine/<int:mid>')
def delete_medicine(mid):
    db = get_db(); cur = db.cursor()
    cur.execute("DELETE FROM medicines WHERE MED_ID=:1", [mid])
    db.commit(); cur.close(); db.close()
    flash("Medicine deleted successfully!", "success")
    return redirect(url_for('view_medicines'))

@app.route('/admin/update-medicine', methods=['POST'])
def update_medicine():
    mid = request.form['id']; name = request.form['name']
    qty = request.form['qty']; price = request.form['price']; expiry = request.form['expiry']
    db = get_db(); cur = db.cursor()
    cur.execute("""
        UPDATE medicines
        SET NAME=:1, QTY=:2, PRICE=:3, EXPIRY=:4
        WHERE MED_ID=:5
    """, (name, qty, price, expiry, mid))
    db.commit(); cur.close(); db.close()
    flash("Medicine updated successfully!", "success")
    return redirect(url_for('view_medicines'))

# ---------------- PHARMACISTS ----------------
@app.route('/admin/pharmacists')
def view_pharmacists():
    db = get_db(); cur = db.cursor()
    filter_type = request.args.get('filter', 'all')  # get ?filter=my

    if filter_type == 'my' and 'company_id' in session:
        cur.execute("""
            SELECT u.USER_ID, u.USERNAME, u.ROLE, c.NAME AS COMPANY_NAME
            FROM USERS u
            JOIN COMPANIES c ON u.COMPANY_ID = c.COMPANY_ID
            WHERE u.ROLE='PHARMACIST' AND u.COMPANY_ID=:1
        """, [session['company_id']])
    else:
        cur.execute("""
            SELECT u.USER_ID, u.USERNAME, u.ROLE, c.NAME AS COMPANY_NAME
            FROM USERS u
            JOIN COMPANIES c ON u.COMPANY_ID = c.COMPANY_ID
            WHERE u.ROLE='PHARMACIST'
        """)

    pharmacists = cur.fetchall(); cur.close(); db.close()
    return render_template('admin_dashboard.html', page='view_pharma', pharmacists=pharmacists)

@app.route('/admin/add-pharmacist', methods=['GET','POST'])
def add_pharmacist():
    form = AddPharmacistForm()
    # Admin can only add pharmacist to their company
    form.company_id.choices = [(session['company_id'], 'My Company')]

    if form.validate_on_submit():
        hashed = bcrypt.hashpw(form.password.data.encode(), bcrypt.gensalt()).decode()
        db = get_db(); cur = db.cursor()
        cur.execute("""
            INSERT INTO users (USER_ID, USERNAME, PASSWORD, ROLE, COMPANY_ID)
            VALUES (user_seq.NEXTVAL, :1, :2, 'PHARMACIST', :3)
        """, (form.username.data, hashed, session['company_id']))
        db.commit(); cur.close(); db.close()
        flash("Pharmacist added successfully!", "success")
        return redirect(url_for('view_pharmacists'))

    return render_template('admin_dashboard.html', page='add_pharma', form=form)

# ---------------- RUN ----------------
if __name__ == '__main__':
    app.run(debug=True)
