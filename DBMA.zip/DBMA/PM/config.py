DB_USER = "PMS_DB"
DB_PASS = "pms123"
DB_DSN  = "localhost:1521/XEPDB1"
import os

SECRET_KEY = os.urandom(24)

SECRET_KEY = "pms_secret_key"
LOW_STOCK_LIMIT = 10
