from flask import Blueprint, render_template, session, redirect

pharmacist_bp = Blueprint('pharmacist', __name__, url_prefix='/pharmacist')

@pharmacist_bp.route('/dashboard')
def dashboard():
    if session.get('role') != 'PHARMACIST':
        return redirect('/login')
    return render_template('pharmacist_dashboard.html')
