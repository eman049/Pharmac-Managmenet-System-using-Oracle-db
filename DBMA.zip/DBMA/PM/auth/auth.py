from flask import Blueprint, render_template, redirect, session
from forms import LoginForm, SignupForm
from db import get_connection

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET','POST'])
def login():
    form = LoginForm()
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT company_id, name FROM company")
    form.company.choices = cur.fetchall()

    error = None
    if form.validate_on_submit():
        cur.execute("""
            SELECT user_id, role FROM users
            WHERE username=:1 AND password=:2 AND company_id=:3
        """,(form.username.data, form.password.data, form.company.data))
        user = cur.fetchone()
        if user:
            session['uid'] = user[0]
            session['role'] = user[1]
            return redirect('/dashboard')
        error = "Invalid Login Details"

    conn.close()
    return render_template('login.html', form=form, error=error)

@auth_bp.route('/signup', methods=['GET','POST'])
def signup():
    form = SignupForm()
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT company_id, name FROM company")
    form.company.choices = cur.fetchall()

    msg = error = None
    if form.validate_on_submit():
        try:
            cur.execute("""
                INSERT INTO users
                VALUES(users_seq.NEXTVAL, :1, :2, :3, :4)
            """,(form.username.data, form.password.data,
                 form.role.data, form.company.data))
            conn.commit()
            msg = "Account Created Successfully"
        except:
            error = "Username Already Exists"

    conn.close()
    return render_template('signup.html', form=form, msg=msg, error=error)

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect('/')
