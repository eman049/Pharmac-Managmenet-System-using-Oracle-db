import oracledb

def get_db_connection():
    conn = oracledb.connect(
        user="PMS_DB",
        password="pms123",
        dsn="localhost:1521/XEPDB1"  # Thin mode: host:port/service_name
    )
    return conn
