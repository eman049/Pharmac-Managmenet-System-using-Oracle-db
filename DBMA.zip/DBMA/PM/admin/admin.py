from flask import Blueprint, render_template, session, redirect

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/dashboard')
def dashboard():
    if session.get('role') != 'ADMIN':
        return redirect('/login')
    return render_template('admin_dashboard.html')
