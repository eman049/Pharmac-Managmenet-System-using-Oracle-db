# =============================
# Smart Pharmacy Management - app.py
# =============================

from flask import Flask, abort, jsonify, render_template, redirect, url_for, session, flash, request
from flask_wtf import FlaskForm, CSRFProtect
from wtforms import StringField, PasswordField, SubmitField, SelectField, IntegerField, FloatField, DateField
from wtforms.validators import DataRequired
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import oracledb
import bcrypt

# ---------------- APP SETUP ----------------
app = Flask(__name__)
app.secret_key = "secret123"
csrf = CSRFProtect(app)

# ---------------- DB CONNECTION ----------------
def get_db():
    return oracledb.connect(
        user="PMS_DB",
        password="pms123",
        dsn="localhost:1521/XEPDB1"
    )

def fetch_companies():
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT COMPANY_ID, NAME FROM COMPANIES ORDER BY COMPANY_ID")
    rows = cur.fetchall()
    cur.close(); db.close()
    return rows

def fetch_users():
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT USERNAME, PASSWORD, ROLE, COMPANY_ID FROM USERS")
    rows = cur.fetchall()
    users = []
    for u in rows:
        cur.execute("SELECT NAME FROM COMPANIES WHERE COMPANY_ID=:1", [u[3]])
        cname = cur.fetchone()[0]
        users.append({
            "username": u[0],
            "password": u[1],
            "role": u[2],
            "company": cname,
            "company_id": u[3]
        })
    cur.close(); db.close()
    return users

# ---------------- FORMS ----------------
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    company = SelectField('Company', validators=[DataRequired()])
    submit = SubmitField('Login')

class SignupForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    role = SelectField('Role', choices=[('ADMIN','ADMIN'), ('PHARMACIST','PHARMACIST')])
    company = SelectField('Company', validators=[DataRequired()])
    submit = SubmitField('Signup')

class AddMedicineForm(FlaskForm):
    name = StringField('Medicine Name', validators=[DataRequired()])
    qty = IntegerField('Quantity', validators=[DataRequired()])
    price = FloatField('Price', validators=[DataRequired()])
    expiry = DateField('Expiry', format='%Y-%m-%d', validators=[DataRequired()])
    company_id = SelectField('Company', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Save Medicine')

class AddPharmacistForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    company_id = SelectField('Company', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Add Pharmacist')

# ---------------- AUTH ROUTES ----------------
# ---------------- AUTH ROUTES ----------------
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/login', methods=['GET','POST'])
def login():
    form = LoginForm()
    form.company.choices = [(c[1], c[1]) for c in fetch_companies()]
    users = fetch_users()

    if form.validate_on_submit():
        user = next(
            (u for u in users if u['username'] == form.username.data and u['company'] == form.company.data),
            None
        )

        if user and bcrypt.checkpw(form.password.data.encode(), user['password'].encode()):
            
            # ---------------- Session ----------------
            session['uid'] = user['username']
            session['role'] = user['role']
            session['company_id'] = user['company_id']
            session['company_name'] = user['company']

            # ---------------- Login Audit ----------------
            db = get_db()
            cur = db.cursor()
            try:
                cur.execute("""
                    INSERT INTO LOGIN_AUDIT 
                    (LOG_ID, USERNAME, ROLE, COMPANY_ID, COMPANY_NAME, ACTION, LOG_TIME)
                    VALUES 
                    (login_audit_seq.NEXTVAL, :1, :2, :3, :4, 'LOGIN', SYSDATE)
                """, [
                    user['username'],
                    user['role'],
                    user['company_id'],
                    user['company']
                ])
                db.commit()
            except Exception as e:
                db.rollback()
                print("Login audit error:", e)
            finally:
                cur.close()
                db.close()

            flash(f"Welcome {user['username']}!", "success")
            return redirect(url_for('dashboard'))

        flash('Invalid credentials', 'error')

    return render_template('login.html', form=form)



@app.route('/signup', methods=['GET','POST'])
def signup():
    form = SignupForm()
    form.company.choices = [(c[1], c[1]) for c in fetch_companies()]
    if form.validate_on_submit():
        db = get_db(); cur = db.cursor()

        # Hash password
        hashed = bcrypt.hashpw(form.password.data.encode(), bcrypt.gensalt()).decode()

        # Get company ID
        cur.execute("SELECT COMPANY_ID FROM COMPANIES WHERE NAME=:1", [form.company.data])
        cid = cur.fetchone()[0]

        # Insert user
        cur.execute("""
            INSERT INTO USERS (USER_ID, USERNAME, PASSWORD, ROLE, COMPANY_ID)
            VALUES (user_seq.NEXTVAL, :1, :2, :3, :4)
        """, (form.username.data, hashed, form.role.data, cid))

        # ---------------- User Signup Audit ----------------
        cur.execute("""
        INSERT INTO LOGIN_AUDIT (LOG_ID, USERNAME, ACTION, LOG_TIME, ROLE, COMPANY_ID, COMPANY_NAME)
        VALUES (login_audit_seq.NEXTVAL, :1, 'LOGIN', SYSDATE, :2, :3, :4)
        """, [user['username'], user['role'], user['company_id'], user['company']])


        db.commit()
        cur.close()
        db.close()
        flash("Account created! Please login.", "success")
        return redirect(url_for('login'))

    return render_template('signup.html', form=form)
from datetime import datetime

@app.template_filter('strftime')
def _jinja2_filter_datetime(date, fmt="%d-%b-%Y"):
    if date is None:
        return ""
    return date.strftime(fmt)



@app.route('/admin/audit-log')
def view_audit_log():
    if session.get('role') != 'ADMIN':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    db = get_db()
    cur = db.cursor()

    # Fetch audit logs
    cur.execute("""
        SELECT LOG_ID, USERNAME, ROLE, COMPANY_ID, COMPANY_NAME, ACTION, LOG_TIME
        FROM LOGIN_AUDIT
        ORDER BY LOG_TIME DESC
    """)
    audit_logs = cur.fetchall()
    cur.close(); db.close()

    return render_template('admin_dashboard.html', page='audit_log', audit_logs=audit_logs)


@app.route('/logout')
def logout():
    if 'uid' in session:
        # ---------------- Logout Audit ----------------
        db = get_db()
        cur = db.cursor()
        cur.execute("""
        INSERT INTO LOGIN_AUDIT (LOG_ID, USERNAME, ACTION, LOG_TIME, ROLE, COMPANY_ID, COMPANY_NAME)
        VALUES (login_audit_seq.NEXTVAL, :1, 'LOGOUT', SYSDATE, :2, :3, :4)
        """, [session['uid'], session['role'], session['company_id'], session['company_name']])

        db.commit()
        cur.close()
        db.close()

    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for('home'))



# ---------------- DASHBOARD ----------------
@app.route('/dashboard')
def dashboard():
    if not session.get('uid'):
        flash("Please login first.", "error")
        return redirect(url_for('login'))
    if session.get('role') == 'ADMIN':
        return redirect(url_for('admin_dashboard'))
    else:
        return redirect(url_for('pharmacist_dashboard'))

# ================== ADMIN DASHBOARD ==================
@app.route('/admin_dashboard')
def admin_dashboard():
    # Only allow ADMIN
    if session.get('role') != 'ADMIN':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    db = get_db()
    cur = db.cursor()

    # -------------------------
    # Fetch all medicines
    # -------------------------
    cur.execute("""
        SELECT MED_ID AS ID,
               NAME AS NAME,
               QTY AS QTY,
               PRICE AS PRICE,
               EXPIRY AS EXPIRY
        FROM MEDICINES
    """)
    medicines = cur.fetchall()

    # Total sold medicines
    cur.execute("SELECT NVL(SUM(QTY_SOLD),0) FROM MED_SALES")
    total_sold = cur.fetchone()[0]

# Medicine report by company
    cur.execute("""
    SELECT COMPANY_ID, NVL(SUM(QTY_SOLD),0)
    FROM MED_SALES
    GROUP BY COMPANY_ID
    """)
    med_report = cur.fetchall()

    # Low stock medicines
    cur.execute("SELECT NAME, QTY FROM MEDICINES WHERE QTY < 10")
    low_stock_meds = cur.fetchall()
    low_stock_count = len(low_stock_meds)
    low_stock_names = ", ".join([f"{m[0]} ({m[1]})" for m in low_stock_meds])

    # -------------------------
    # Medicine Audit Log
    # -------------------------
    cur.execute("""
        SELECT AUDIT_ID, MED_ID, NAME, QTY, PRICE, EXPIRY, COMPANY_ID, ACTION, CHANGED_AT
        FROM MEDICINE_AUDIT_LOG
        ORDER BY CHANGED_AT DESC
    """)
    audit_log = cur.fetchall()

    # -------------------------
    # Other summary info
    # -------------------------
    total_medicines = len(medicines)
    cur.execute("SELECT COUNT(*) FROM USERS WHERE ROLE='PHARMACIST'")
    total_pharmacists = cur.fetchone()[0]

    cur.close()
    db.close()

    return render_template('admin_dashboard.html',
                       page='dashboard',
                       medicines=medicines,
                       total_sold=total_sold,
                       med_report=med_report,
                       audit_log=audit_log,
                       total_medicines=total_medicines,
                       total_pharmacists=total_pharmacists,
                       low_stock_meds=low_stock_meds,
                       low_stock_names=low_stock_names)



# ---------------- MEDICINES ----------------
@app.route('/admin/medicines')
def view_medicines():
    if session.get('role') != 'ADMIN':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    db = get_db(); cur = db.cursor()
    cur.execute("SELECT MED_ID, NAME, QTY, PRICE, EXPIRY FROM MEDICINES")
    meds = cur.fetchall(); cur.close(); db.close()
    return render_template('admin_dashboard.html', page='view_medicine', medicines=meds)

@app.route('/admin/add-medicine', methods=['GET','POST'])
def add_medicine():
    if session.get('role') != 'ADMIN':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    form = AddMedicineForm()
    form.company_id.choices = fetch_companies()
    if form.validate_on_submit():
        db = get_db(); cur = db.cursor()
        cur.execute("""
            INSERT INTO MEDICINES (MED_ID, NAME, QTY, PRICE, EXPIRY, COMPANY_ID)
            VALUES (med_seq.NEXTVAL, :1, :2, :3, :4, :5)
        """, (form.name.data, form.qty.data, form.price.data, form.expiry.data, form.company_id.data))
        db.commit(); cur.close(); db.close()
        flash("Medicine added successfully!", "success")
        return redirect(url_for('view_medicines'))
    return render_template('admin_dashboard.html', page='add_medicine', form=form)

@app.route('/admin/delete-medicine/<int:mid>')
def delete_medicine(mid):
    if session.get('role') != 'ADMIN':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    db = get_db(); cur = db.cursor()
    cur.execute("DELETE FROM MEDICINES WHERE MED_ID=:1", [mid])
    db.commit(); cur.close(); db.close()
    flash("Medicine deleted successfully!", "success")
    return redirect(url_for('view_medicines'))

from datetime import datetime

@app.route('/admin/update-medicine', methods=['POST'])
def update_medicine():
    if session.get('role') != 'ADMIN':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    mid = request.form['id']
    name = request.form['name']
    qty = request.form['qty']
    price = request.form['price']

    # ✅ FIX: convert string → date
    expiry_str = request.form['expiry']          # "2025-12-18"
    expiry = datetime.strptime(expiry_str, "%Y-%m-%d").date()

    db = get_db()
    cur = db.cursor()

    cur.execute("""
        UPDATE MEDICINES
        SET NAME = :1,
            QTY = :2,
            PRICE = :3,
            EXPIRY = :4
        WHERE MED_ID = :5
    """, (name, qty, price, expiry, mid))

    db.commit()
    cur.close()
    db.close()

    flash("Medicine updated successfully!", "success")
    return redirect(url_for('view_medicines'))

# ---------------- PHARMACISTS ----------------
@app.route('/admin/pharmacists')
def view_pharmacists():
    db = get_db(); cur = db.cursor()
    filter_type = request.args.get('filter', 'all')  # get ?filter=my

    if filter_type == 'my' and 'company_id' in session:
        cur.execute("""
            SELECT u.USER_ID, u.USERNAME, u.ROLE, c.NAME AS COMPANY_NAME
            FROM USERS u
            JOIN COMPANIES c ON u.COMPANY_ID = c.COMPANY_ID
            WHERE u.ROLE='PHARMACIST' AND u.COMPANY_ID=:1
        """, [session['company_id']])
    else:
        cur.execute("""
            SELECT u.USER_ID, u.USERNAME, u.ROLE, c.NAME AS COMPANY_NAME
            FROM USERS u
            JOIN COMPANIES c ON u.COMPANY_ID = c.COMPANY_ID
            WHERE u.ROLE='PHARMACIST'
        """)

    pharmacists = cur.fetchall(); cur.close(); db.close()
    return render_template('admin_dashboard.html', page='view_pharma', pharmacists=pharmacists)

@app.route('/admin/add-pharmacist', methods=['GET', 'POST'])
def add_pharmacist():
    # safety check
    if 'company_id' not in session:
        abort(403)

    form = AddPharmacistForm()

    # admin sirf apni company mein add kare
    form.company_id.choices = [
        (session['company_id'], 'My Company')
    ]

    if form.validate_on_submit():
        try:
            hashed = bcrypt.hashpw(
                form.password.data.encode(),
                bcrypt.gensalt()
            ).decode()

            db = get_db()
            cur = db.cursor()

            cur.execute("""
                INSERT INTO users (USER_ID, USERNAME, PASSWORD, ROLE, COMPANY_ID)
                VALUES (user_seq.NEXTVAL, :1, :2, 'PHARMACIST', :3)
            """, (
                form.username.data,
                hashed,
                session['company_id']
            ))

            db.commit()
            cur.close()
            db.close()

            flash(" Pharmacist added successfully!", "success")
            return redirect(url_for('view_pharmacists'))

        except Exception as e:
            flash(f" Error: {str(e)}", "error")

    elif request.method == 'POST':
        flash(" Form validation failed", "error")

    return render_template(
        'admin_dashboard.html',
        page='add_pharma',
        form=form
    )
@app.route('/admin_dashboard_api')
def admin_dashboard_api():
    if session.get('role') != 'ADMIN':
        abort(403)

    db = get_db()
    cur = db.cursor()

    # Total medicines
    cur.execute("SELECT COUNT(*) FROM MEDICINES")
    total_meds = cur.fetchone()[0]

    #  SOLD medicines (REAL)
    cur.execute("SELECT NVL(SUM(QTY_SOLD),0) FROM MED_SALES")
    total_sold = cur.fetchone()[0]

    # Low stock medicines (with qty)
    cur.execute("""
        SELECT MED_ID, NAME, QTY
        FROM MEDICINES
        WHERE QTY < 10
    """)
    low_stock = cur.fetchall()

    # ---------- MEDICINE REPORT (ADMIN) ----------
    cur.execute("""
    SELECT COMPANY_ID, SUM(TOTAL_MEDS) AS TOTAL_MEDS
    FROM MED_REPORT
    GROUP BY COMPANY_ID
    ORDER BY COMPANY_ID
    """)
    med_report = cur.fetchall()


    cur.close(); db.close()

    return jsonify({
    "total_meds": total_meds,
    "total_sold": total_sold,
    "low_stock": low_stock,      # <-- full list
    "med_report": med_report     # <-- company wise
})



@app.route('/pharmacist_dashboard')
def pharmacist_dashboard():
    if session.get('role') != 'PHARMACIST':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    db = get_db()
    cur = db.cursor()

    # Company of logged-in pharmacist
    cur.execute("SELECT COMPANY_ID FROM USERS WHERE USERNAME=:1", [session['uid']])
    company_id = cur.fetchone()[0]

    # Fetch medicines of this company
    cur.execute("""
        SELECT MED_ID, NAME, NVL(QTY,0), NVL(PRICE,0), EXPIRY
        FROM MEDICINES
        WHERE COMPANY_ID=:1
    """, [company_id])
    medicines = cur.fetchall() or []

    # Low stock
    low_stock = [m for m in medicines if m[2] < 10]

    # Total sold medicines
    cur.execute("SELECT NVL(SUM(QTY_SOLD),0) FROM MED_SALES WHERE COMPANY_ID=:1", [company_id])
    total_sold = cur.fetchone()[0] or 0

    # Current stock sum
    cur.execute("SELECT NVL(SUM(QTY),0) FROM MEDICINES WHERE COMPANY_ID=:1", [company_id])
    current_stock = cur.fetchone()[0] or 0
# Medicine report (company-wise from MED_SALES)
    cur.execute("""
    SELECT COMPANY_ID, NVL(SUM(QTY_SOLD),0)
    FROM MED_SALES
    WHERE COMPANY_ID=:1
    GROUP BY COMPANY_ID
    """, [company_id])
    med_report = cur.fetchall()

    # Chart data (per medicine)
    labels = [m[1] for m in medicines]            # medicine names
    stock_data = [m[2] for m in medicines]        # current stock
    sold_data_list = []
    for m in medicines:
        cur.execute("SELECT NVL(SUM(QTY_SOLD),0) FROM MED_SALES WHERE MED_ID=:1 AND COMPANY_ID=:2", [m[0], company_id])
        sold_qty = cur.fetchone()[0] or 0
        sold_data_list.append(sold_qty)

    cur.close()
    db.close()

    return render_template(
    'pharmacist_dashboard.html',
    medicines=medicines,
    low_stock=low_stock,
    total_sold=total_sold,
    current_stock=current_stock,
    med_report=med_report,
    labels=labels,
    stock_data=stock_data,
    sold_data_list=sold_data_list
)


@app.route("/sell_medicine_ajax", methods=["POST"])
def sell_medicine_ajax():
    if session.get('role') != 'PHARMACIST':
        return jsonify(success=False, message="Access denied!")

    med_id = request.form.get("med_id")
    qty = request.form.get("qty")

    # Validate quantity
    try:
        qty = int(qty)
        if qty <= 0:
            raise ValueError
    except:
        return jsonify(success=False, message="Invalid quantity")

    db = get_db()
    cur = db.cursor()

    try:
        #  Lock the medicine row
        cur.execute("""
            SELECT QTY
            FROM MEDICINES
            WHERE MED_ID=:1
            FOR UPDATE
        """, [med_id])
        row = cur.fetchone()

        if not row:
            return jsonify(success=False, message="Medicine not found")

        current_stock = row[0]

        if qty > current_stock:
            return jsonify(success=False, message=f"Only {current_stock} available")

        # Update stock
        new_stock = current_stock - qty
        cur.execute("UPDATE MEDICINES SET QTY=:1 WHERE MED_ID=:2", [new_stock, med_id])

        # Insert into audit table
        cur.execute("""
            INSERT INTO MED_SALES_AUDIT
            (AUDIT_ID, USERNAME, MED_ID, SOLD_QTY, OLD_STOCK, NEW_STOCK, ACTION_DATE)
            VALUES
            (med_sales_audit_seq.NEXTVAL, :1, :2, :3, :4, :5, SYSDATE)
        """, (
            session['uid'],
            med_id,
            qty,
            current_stock,
            new_stock
        ))

        # Update MED_SALES table
        cur.execute("""
            MERGE INTO MED_SALES ms
            USING (SELECT :1 AS MED_ID, :2 AS QTY_SOLD FROM DUAL) src
            ON (ms.MED_ID = src.MED_ID)
            WHEN MATCHED THEN
                UPDATE SET ms.QTY_SOLD = ms.QTY_SOLD + src.QTY_SOLD
            WHEN NOT MATCHED THEN
                INSERT (MED_ID, QTY_SOLD)
                VALUES (src.MED_ID, src.QTY_SOLD)
        """, [med_id, qty])

        db.commit()

        # 🔢 Refresh totals
        # Total current stock
        cur.execute("SELECT NVL(SUM(QTY),0) FROM MEDICINES")
        total_stock = cur.fetchone()[0] or 0

        # Total sold
        cur.execute("SELECT NVL(SUM(QTY_SOLD),0) FROM MED_SALES")
        total_sold = cur.fetchone()[0] or 0

        # Low stock medicines
        cur.execute("SELECT NAME, QTY FROM MEDICINES WHERE QTY < 10")
        low_stock = cur.fetchall()

           # total medicines = current stock + sold
        total_meds = total_stock + total_sold
        return jsonify(
         success=True,
    new_stock=new_stock,
    total_meds=total_meds,  # <-- use this key
    total_sold=total_sold,
    low_stock_count=len(low_stock),
    low_stock_names=", ".join(f"{m[0]} ({m[1]})" for m in low_stock)
)


    except Exception as e:
        db.rollback()
        return jsonify(success=False, message=str(e))

    finally:
        cur.close()
        db.close()


# ================= UPDATE PROFILE ==================
@app.route('/update_profile', methods=['POST'])
def update_profile():
    if session.get('role') != 'PHARMACIST':
        flash("Access denied!", "error")
        return redirect(url_for('login'))

    new_password = bcrypt.hashpw(request.form['new_password'].encode(), bcrypt.gensalt()).decode()
    db = get_db()
    cur = db.cursor()
    cur.execute("UPDATE USERS SET PASSWORD=:1 WHERE USERNAME=:2", [new_password, session['uid']])
    db.commit()
    cur.close()
    db.close()

    flash("Password updated successfully!", "success")
    return redirect(url_for('pharmacist_dashboard'))

# ---------------- RUN APP ----------------
if __name__ == '__main__':
    app.run(debug=True)
