document.addEventListener('DOMContentLoaded', function(){
    const btns = document.querySelectorAll('.btn');
    btns.forEach(btn => {
        btn.addEventListener('mouseenter', () => {
            btn.style.boxShadow = '0 0 25px #ff0';
        });
        btn.addEventListener('mouseleave', () => {
            btn.style.boxShadow = '0 0 15px #0ff';
        });
    });
});
